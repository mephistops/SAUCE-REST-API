# -*- coding: utf-8 -*-

from . import res_config_settings
from . import petrol_pumps
from . import supply_points
from . import gas_suppliers
from . import turns
from . import hr_employees
from . import product_template